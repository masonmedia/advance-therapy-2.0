<?php include './includes/header.php'; ?>
<?php echo $navClass = "bg-teal"; include './includes/nav.php'; ?>

<div class="container-fluid bg-teal">
    <div class="row bg-pattern">
        <div class="col-sm-12 align-center min-100 p-5">
            <!-- <h1 class="footer-404 absolute z-0 text-light font-weight-bold m-0" style="font-size: 50vmin; opacity: 0.1; text-shadow: 2px 2px 5px #000; letter-spacing: -35px;">404</h1> -->
            <h1 class="page_title my-2">Page Not Found</h1>
            <p>Sorry, the page you were trying to view does not exist.</p>
        </div>
    </div>
</div>

<?php include './includes/footer.php'; ?>
