<?php include './includes/header.php'; ?>
<?php $navClass = "bg-perfect-white"; include './includes/nav.php'; ?>

  <div class="container-fluid pt-4">
    <?php include './includes/partials/therapists_page.php'; ?>
  </div>

 <?php include './includes/footer.php'; ?>
