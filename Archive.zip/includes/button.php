<a href="<?php echo $btnLink; ?>" data-scroll data-aos="zoom-in" data-aos-offset="20">
    <button class="btn btn-lg <?php echo $btnClass; ?>">
        <?php echo $btnText; ?>
    </button>
</a>