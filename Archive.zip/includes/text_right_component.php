  <div class="col-lg-5 align-left p-5 min-50" data-aos="fade-right">
    <!-- arrow -->
      <div 
      class="arrow display-2 font-weight-bold <?php echo $arrowClass; ?>">↘</div>
      <!-- title -->
      <h2 class="section_title">
        <?php echo $title; ?>
      </h2>
      <p>
        <?php echo $text; ?>
      </p>
      <!-- button/link -->
      <?php include './includes/button.php'; ?>
    </div>
  <div class="offset-lg-1"></div>