<?php include './includes/header.php'; ?>
<?php $navClass = "bg-salt-mountain"; include './includes/nav.php'; ?>

  <div class="container-fluid pt-4">
    <?php include './includes/partials/services_page.php'; ?>
  </div>

 <?php include './includes/footer.php'; ?>
